# Smart Hostel Management System — Backend

Spring Boot 3 + Oracle SQL backend generated to match the data model and
functions used in `app14.html` (the Smart Hostel dashboard mockup).

## 1. Prerequisites

- Java 17+
- Maven 3.8+
- Oracle Database (XE, standalone, or Autonomous DB) reachable from this app

## 2. Database setup

1. Create a schema/user, e.g.:
   ```sql
   CREATE USER hostel_admin IDENTIFIED BY hostel_pass;
   GRANT CONNECT, RESOURCE, DBA TO hostel_admin; -- or narrower privileges in prod
   ```
2. Run the DDL manually (recommended for production):
   ```
   sqlplus hostel_admin/hostel_pass@//localhost:1521/XEPDB1 @src/main/resources/oracle-schema.sql
   sqlplus hostel_admin/hostel_pass@//localhost:1521/XEPDB1 @src/main/resources/oracle-seed-data.sql
   ```
   OR, for local development, leave `spring.jpa.hibernate.ddl-auto=update` in
   `application.properties` and let Hibernate create/update the tables
   automatically from the entity classes on startup (then optionally run
   `oracle-seed-data.sql` to load the same sample data as the mockup).

3. Update `src/main/resources/application.properties` with your actual
   Oracle host/port/service name and credentials.

## 3. Build & run

```bash
mvn clean install
mvn spring-boot:run
```

The API starts on `http://localhost:8080`.

## 4. Project structure

```
com.smarthostel
 ├── entity/       13 JPA entities (Student, GatePass, Complaint, Fee, Alert,
 │                 SickFoodRequest, MealOptOut, FoodFeedback, Laundry,
 │                 MessMenu, CleaningRequest, ParentMessage, WardenProfile)
 ├── repository/   Spring Data JPA repositories for each entity
 ├── service/      Business logic mirroring the original frontend JS functions
 │                 (markAttendance -> toggleAttendance, applyGatePass -> apply,
 │                 payFee -> pay, triggerSOS -> triggerSos, etc.)
 ├── controller/   REST controllers exposing everything under /api/**
 └── config/       CorsConfig (allows the HTML dashboard to call the API)
```

## 5. REST API summary

| Resource | Endpoints |
|---|---|
| Auth | `POST /api/auth/login` |
| Students | `GET/POST /api/students`, `GET/PUT/DELETE /api/students/{id}`, `PATCH /api/students/{id}/attendance/toggle`, `PATCH /api/students/{id}/attendance`, `PATCH /api/students/{id}/mess-token/consume` |
| Warden profile | `GET/PUT /api/warden-profile` |
| Gate passes | `GET/POST /api/gate-passes`, `PATCH /api/gate-passes/{id}/approve`, `PATCH /api/gate-passes/{id}/return`, `POST /api/gate-passes/check-overdue` |
| Complaints | `GET/POST /api/complaints`, `PATCH /api/complaints/{id}/status` |
| Fees | `GET/POST /api/fees`, `PATCH /api/fees/{id}/pay`, `POST /api/fees/check-deadlines?studentId=` |
| Alerts | `GET /api/alerts`, `POST /api/alerts/sos?studentId=` |
| Sick food requests | `GET/POST /api/sick-food-requests`, `PATCH /api/sick-food-requests/{id}/status` |
| Meal opt-outs | `GET/POST /api/meal-opt-outs` |
| Food feedback | `GET/POST /api/food-feedback` |
| Laundry | `GET/POST /api/laundry`, `PATCH /api/laundry/{id}/status` |
| Mess menu | `GET/PUT /api/mess-menu` |
| Cleaning requests | `GET/POST /api/cleaning-requests`, `PATCH /api/cleaning-requests/{id}/status` |
| Parent messages | `GET/POST /api/parent-messages`, `PATCH /api/parent-messages/{id}/read` |

All list endpoints accept an optional `?studentId=` query parameter to filter
to one student's records (used by the student/parent dashboards).

## 6. Connecting the existing HTML frontend

`app14.html` currently keeps all data in an in-memory `db` JS object. To wire
it to this backend, replace the direct `db.xxx` array mutations with `fetch()`
calls to the endpoints above (e.g. `submitComplaint()` -> `fetch('/api/complaints', {method:'POST', body: JSON.stringify(...)})`), and hydrate the initial
`db` object from the corresponding `GET` endpoints on load instead of the
hardcoded arrays.
