package com.smarthostel.controller;

import com.smarthostel.entity.ParentMessage;
import com.smarthostel.service.ParentMessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parent-messages")
@RequiredArgsConstructor
public class ParentMessageController {

    private final ParentMessageService service;

    @GetMapping
    public List<ParentMessage> getAll(@RequestParam(required = false) String studentId) {
        return studentId != null ? service.getByStudent(studentId) : service.getAll();
    }

    @PostMapping
    public ParentMessage send(@RequestBody ParentMessage msg) {
        return service.send(msg);
    }

    @PatchMapping("/{id}/read")
    public ParentMessage markRead(@PathVariable String id) {
        return service.markRead(id);
    }
}
