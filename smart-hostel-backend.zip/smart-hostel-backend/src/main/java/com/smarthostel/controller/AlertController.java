package com.smarthostel.controller;

import com.smarthostel.entity.Alert;
import com.smarthostel.entity.Student;
import com.smarthostel.service.AlertService;
import com.smarthostel.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/alerts")
@RequiredArgsConstructor
public class AlertController {

    private final AlertService alertService;
    private final StudentService studentService;

    @GetMapping
    public List<Alert> getAll() {
        return alertService.getAll();
    }

    // Equivalent of frontend triggerSOS()
    @PostMapping("/sos")
    public Alert triggerSos(@RequestParam String studentId) {
        String room = studentService.getById(studentId).map(Student::getRoom).orElse("Unknown");
        return alertService.triggerSos(studentId, room);
    }
}
