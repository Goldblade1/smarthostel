package com.smarthostel.controller;

import com.smarthostel.entity.Fee;
import com.smarthostel.service.FeeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/fees")
@RequiredArgsConstructor
public class FeeController {

    private final FeeService feeService;

    @GetMapping
    public List<Fee> getAll() {
        return feeService.getAll();
    }

    @PostMapping
    public Fee create(@RequestBody Fee fee) {
        return feeService.create(fee);
    }

    @PatchMapping("/{id}/pay")
    public Fee pay(@PathVariable String id) {
        return feeService.pay(id);
    }

    @PostMapping("/check-deadlines")
    public void checkDeadlines(@RequestParam String studentId) {
        feeService.checkDeadlines(studentId);
    }
}
