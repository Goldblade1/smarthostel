package com.smarthostel.controller;

import com.smarthostel.entity.SickFoodRequest;
import com.smarthostel.service.SickFoodRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sick-food-requests")
@RequiredArgsConstructor
public class SickFoodRequestController {

    private final SickFoodRequestService service;

    @GetMapping
    public List<SickFoodRequest> getAll(@RequestParam(required = false) String studentId) {
        return studentId != null ? service.getByStudent(studentId) : service.getAll();
    }

    @PostMapping
    public SickFoodRequest request(@RequestBody SickFoodRequest req) {
        return service.request(req);
    }

    @PatchMapping("/{id}/status")
    public SickFoodRequest updateStatus(@PathVariable String id, @RequestBody Map<String, String> body) {
        return service.updateStatus(id, body.get("status"));
    }
}
