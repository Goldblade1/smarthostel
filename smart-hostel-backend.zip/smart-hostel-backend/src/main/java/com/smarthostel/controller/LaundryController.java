package com.smarthostel.controller;

import com.smarthostel.entity.Laundry;
import com.smarthostel.service.LaundryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/laundry")
@RequiredArgsConstructor
public class LaundryController {

    private final LaundryService service;

    @GetMapping
    public List<Laundry> getAll(@RequestParam(required = false) String studentId) {
        return studentId != null ? service.getByStudent(studentId) : service.getAll();
    }

    @PostMapping
    public Laundry create(@RequestBody Laundry laundry) {
        return service.create(laundry);
    }

    @PatchMapping("/{id}/status")
    public Laundry updateStatus(@PathVariable String id, @RequestBody Map<String, Object> body) {
        String status = (String) body.get("status");
        Integer progress = body.get("progress") != null ? Integer.valueOf(body.get("progress").toString()) : null;
        return service.updateStatus(id, status, progress);
    }
}
