package com.smarthostel.controller;

import com.smarthostel.entity.MealOptOut;
import com.smarthostel.service.MealOptOutService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/meal-opt-outs")
@RequiredArgsConstructor
public class MealOptOutController {

    private final MealOptOutService service;

    @GetMapping
    public List<MealOptOut> getAll(@RequestParam(required = false) String studentId) {
        return studentId != null ? service.getByStudent(studentId) : service.getAll();
    }

    @PostMapping
    public MealOptOut submit(@RequestBody MealOptOut optOut) {
        return service.submit(optOut);
    }
}
