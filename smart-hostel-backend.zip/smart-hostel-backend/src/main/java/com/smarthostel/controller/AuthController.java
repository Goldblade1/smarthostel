package com.smarthostel.controller;

import com.smarthostel.entity.Student;
import com.smarthostel.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final StudentRepository studentRepository;

    // Equivalent of frontend handleLogin(): student/parent auto-register on first login,
    // warden logs in against the fixed warden profile (no student record created).
    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Map<String, String> body) {
        String loginId = body.getOrDefault("loginId", "S101").toUpperCase();
        String role = body.getOrDefault("role", "student");

        if (!"warden".equals(role) && studentRepository.findById(loginId).isEmpty()) {
            Student newStudent = Student.builder()
                    .id(loginId)
                    .name("Test User")
                    .room("B-205")
                    .present(true)
                    .lastScan("-")
                    .diet("Non-Veg")
                    .messTokenDate(java.time.LocalDate.now().toString())
                    .messTokenConsumed(false)
                    .mobile("0000000000")
                    .parentMobile("0000000000")
                    .email("test@university.edu")
                    .build();
            studentRepository.save(newStudent);
        }

        return Map.of("currentUser", loginId, "currentRole", role);
    }
}
