package com.smarthostel.controller;

import com.smarthostel.entity.GatePass;
import com.smarthostel.service.GatePassService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/gate-passes")
@RequiredArgsConstructor
public class GatePassController {

    private final GatePassService gatePassService;

    @GetMapping
    public List<GatePass> getAll(@RequestParam(required = false) String studentId) {
        return studentId != null ? gatePassService.getByStudent(studentId) : gatePassService.getAll();
    }

    @PostMapping
    public GatePass apply(@RequestBody GatePass pass) {
        return gatePassService.apply(pass);
    }

    @PatchMapping("/{id}/approve")
    public GatePass approve(@PathVariable String id, @RequestBody Map<String, Boolean> body) {
        return gatePassService.approve(id, Boolean.TRUE.equals(body.get("approved")));
    }

    @PatchMapping("/{id}/return")
    public GatePass markReturned(@PathVariable String id) {
        return gatePassService.markReturned(id);
    }

    @PostMapping("/check-overdue")
    public void checkOverdue() {
        gatePassService.checkOverduePasses();
    }
}
