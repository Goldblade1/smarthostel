package com.smarthostel.controller;

import com.smarthostel.entity.Complaint;
import com.smarthostel.service.ComplaintService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/complaints")
@RequiredArgsConstructor
public class ComplaintController {

    private final ComplaintService complaintService;

    @GetMapping
    public List<Complaint> getAll(@RequestParam(required = false) String studentId) {
        return studentId != null ? complaintService.getByStudent(studentId) : complaintService.getAll();
    }

    @PostMapping
    public Complaint submit(@RequestBody Complaint complaint) {
        return complaintService.submit(complaint);
    }

    @PatchMapping("/{id}/status")
    public Complaint updateStatus(@PathVariable String id, @RequestBody Map<String, String> body) {
        return complaintService.updateStatus(id, body.get("status"));
    }
}
