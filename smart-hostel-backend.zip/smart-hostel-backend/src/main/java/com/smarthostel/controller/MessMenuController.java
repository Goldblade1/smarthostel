package com.smarthostel.controller;

import com.smarthostel.entity.MessMenu;
import com.smarthostel.service.MessMenuService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/mess-menu")
@RequiredArgsConstructor
public class MessMenuController {

    private final MessMenuService service;

    @GetMapping
    public MessMenu get() {
        return service.get();
    }

    @PutMapping
    public MessMenu update(@RequestBody MessMenu menu) {
        return service.update(menu);
    }
}
