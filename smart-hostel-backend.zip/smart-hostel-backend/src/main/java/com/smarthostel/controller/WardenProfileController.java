package com.smarthostel.controller;

import com.smarthostel.entity.WardenProfile;
import com.smarthostel.service.WardenProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/warden-profile")
@RequiredArgsConstructor
public class WardenProfileController {

    private final WardenProfileService wardenProfileService;

    @GetMapping
    public WardenProfile get() {
        return wardenProfileService.get();
    }

    @PutMapping
    public WardenProfile update(@RequestBody WardenProfile profile) {
        return wardenProfileService.update(profile);
    }
}
