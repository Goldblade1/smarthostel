package com.smarthostel.controller;

import com.smarthostel.entity.Student;
import com.smarthostel.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    @GetMapping
    public List<Student> getAll() {
        return studentService.getAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Student> getById(@PathVariable String id) {
        return studentService.getById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Student create(@RequestBody Student student) {
        return studentService.create(student);
    }

    @PutMapping("/{id}")
    public Student update(@PathVariable String id, @RequestBody Student student) {
        return studentService.update(id, student);
    }

    // Toggle attendance - mirrors frontend markAttendance()
    @PatchMapping("/{id}/attendance/toggle")
    public Student toggleAttendance(@PathVariable String id) {
        return studentService.toggleAttendance(id);
    }

    // Bulk/manual attendance set - mirrors frontend submitDailyAttendance()
    @PatchMapping("/{id}/attendance")
    public Student setAttendance(@PathVariable String id, @RequestBody Map<String, Object> body) {
        boolean present = Boolean.TRUE.equals(body.get("present"));
        String date = String.valueOf(body.get("date"));
        return studentService.setAttendance(id, present, date);
    }

    // Consume today's mess token - mirrors frontend scanMessToken()
    @PatchMapping("/{id}/mess-token/consume")
    public Student consumeMessToken(@PathVariable String id) {
        return studentService.consumeMessToken(id);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        studentService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
