package com.smarthostel.controller;

import com.smarthostel.entity.CleaningRequest;
import com.smarthostel.service.CleaningRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cleaning-requests")
@RequiredArgsConstructor
public class CleaningRequestController {

    private final CleaningRequestService service;

    @GetMapping
    public List<CleaningRequest> getAll(@RequestParam(required = false) String studentId) {
        return studentId != null ? service.getByStudent(studentId) : service.getAll();
    }

    @PostMapping
    public CleaningRequest submit(@RequestBody CleaningRequest req) {
        return service.submit(req);
    }

    @PatchMapping("/{id}/status")
    public CleaningRequest updateStatus(@PathVariable String id, @RequestBody Map<String, String> body) {
        return service.updateStatus(id, body.get("status"));
    }
}
