package com.smarthostel.controller;

import com.smarthostel.entity.FoodFeedback;
import com.smarthostel.service.FoodFeedbackService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/food-feedback")
@RequiredArgsConstructor
public class FoodFeedbackController {

    private final FoodFeedbackService service;

    @GetMapping
    public List<FoodFeedback> getAll(@RequestParam(required = false) String studentId) {
        return studentId != null ? service.getByStudent(studentId) : service.getAll();
    }

    @PostMapping
    public FoodFeedback submit(@RequestBody FoodFeedback feedback) {
        return service.submit(feedback);
    }
}
