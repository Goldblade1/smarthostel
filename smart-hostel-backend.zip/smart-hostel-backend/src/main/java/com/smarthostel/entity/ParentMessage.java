package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "PARENT_MESSAGES")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ParentMessage {

    @Id
    @Column(name = "MESSAGE_ID", length = 20)
    private String id;                 // e.g. PM1

    @Column(name = "STUDENT_ID", length = 20, nullable = false)
    private String studentId;

    @Column(name = "MESSAGE", length = 2000)
    private String message;

    @Column(name = "MESSAGE_DATE", length = 20)
    private String date;

    @Column(name = "STATUS", length = 20)
    private String status;             // Unread / Read
}
