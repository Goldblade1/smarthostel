package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "GATE_PASSES")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GatePass {

    @Id
    @Column(name = "PASS_ID", length = 20)
    private String id;                 // e.g. GP1

    @Column(name = "STUDENT_ID", length = 20, nullable = false)
    private String studentId;

    @Column(name = "REASON", length = 255)
    private String reason;

    @Column(name = "OUT_DATE", length = 30)
    private String outDate;            // ISO datetime string, e.g. 2026-08-19T08:00

    @Column(name = "EXPECTED_RETURN", length = 30)
    private String expectedReturn;

    @Column(name = "PARENT_MOBILE", length = 15)
    private String parentMobile;

    @Column(name = "STUDENT_MOBILE", length = 15)
    private String studentMobile;

    @Column(name = "ROOM_NO", length = 20)
    private String roomNo;

    @Column(name = "DAYS")
    private Integer days;

    @Column(name = "STATUS", length = 20)
    private String status;             // Pending / Approved / Rejected

    @Column(name = "RETURNED")
    private Boolean returned;
}
