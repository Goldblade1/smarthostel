package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "COMPLAINTS")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Complaint {

    @Id
    @Column(name = "COMPLAINT_ID", length = 20)
    private String id;                 // e.g. C1

    @Column(name = "STUDENT_ID", length = 20, nullable = false)
    private String studentId;

    @Column(name = "CATEGORY", length = 50)
    private String category;           // Electrical / Plumbing / etc.

    @Column(name = "DESCRIPTION", length = 1000)
    private String desc;

    @Column(name = "STATUS", length = 20)
    private String status;             // Pending / In Progress / Resolved
}
