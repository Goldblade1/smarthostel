package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "WARDEN_PROFILE")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WardenProfile {

    @Id
    @Column(name = "WARDEN_ID", length = 20)
    private String id;                 // e.g. W1 - singleton row

    @Column(name = "NAME", length = 100)
    private String name;

    @Column(name = "ZONE", length = 100)
    private String zone;
}
