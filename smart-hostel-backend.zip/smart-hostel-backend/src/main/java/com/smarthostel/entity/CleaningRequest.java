package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "CLEANING_REQUESTS")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CleaningRequest {

    @Id
    @Column(name = "REQUEST_ID", length = 20)
    private String id;                 // e.g. CR1

    @Column(name = "STUDENT_ID", length = 20, nullable = false)
    private String studentId;

    @Column(name = "REQUEST_DATE", length = 20)
    private String date;

    @Column(name = "TIME_SLOT", length = 50)
    private String timeSlot;

    @Column(name = "STATUS", length = 20)
    private String status;             // Pending / Done
}
