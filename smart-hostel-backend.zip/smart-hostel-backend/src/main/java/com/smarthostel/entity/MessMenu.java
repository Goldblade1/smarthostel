package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "MESS_MENU")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MessMenu {

    @Id
    @Column(name = "MENU_ID", length = 20)
    private String id;                 // singleton row, e.g. "CURRENT"

    @Column(name = "BREAKFAST", length = 500)
    private String breakfast;

    @Column(name = "LUNCH", length = 500)
    private String lunch;

    @Column(name = "DINNER", length = 500)
    private String dinner;
}
