package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "ALERTS")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Alert {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ALERT_ID")
    private Long id;

    @Column(name = "TYPE", length = 50)
    private String type;               // Overdue Return / Fee Overdue / EMERGENCY SOS / Daily Attendance

    @Column(name = "STUDENT_ID", length = 20)
    private String studentId;

    @Column(name = "MESSAGE", length = 1000)
    private String message;

    @Column(name = "ALERT_TIME", length = 30)
    private String time;
}
