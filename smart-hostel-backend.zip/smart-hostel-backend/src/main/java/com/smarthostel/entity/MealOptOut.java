package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "MEAL_OPT_OUTS")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MealOptOut {

    @Id
    @Column(name = "OPTOUT_ID", length = 20)
    private String id;                 // e.g. MO1

    @Column(name = "STUDENT_ID", length = 20, nullable = false)
    private String studentId;

    @Column(name = "OPTOUT_DATE", length = 20)
    private String date;

    @Column(name = "MEAL", length = 20)
    private String meal;
}
