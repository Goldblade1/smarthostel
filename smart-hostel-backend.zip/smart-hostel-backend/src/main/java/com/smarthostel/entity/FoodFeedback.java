package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "FOOD_FEEDBACK")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FoodFeedback {

    @Id
    @Column(name = "FEEDBACK_ID", length = 20)
    private String id;                 // e.g. FF1

    @Column(name = "STUDENT_ID", length = 20, nullable = false)
    private String studentId;

    @Column(name = "FEEDBACK_DATE", length = 20)
    private String date;

    @Column(name = "MEAL", length = 20)
    private String meal;

    @Column(name = "RATING", length = 10)
    private String rating;
}
