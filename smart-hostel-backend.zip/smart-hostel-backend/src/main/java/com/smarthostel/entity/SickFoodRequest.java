package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "SICK_FOOD_REQUESTS")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SickFoodRequest {

    @Id
    @Column(name = "REQUEST_ID", length = 20)
    private String id;                 // e.g. SF1

    @Column(name = "STUDENT_ID", length = 20, nullable = false)
    private String studentId;

    @Column(name = "REQUEST_DATE", length = 20)
    private String date;

    @Column(name = "MEAL", length = 20)
    private String meal;               // Breakfast / Lunch / Dinner

    @Column(name = "STATUS", length = 20)
    private String status;             // Pending / Delivered
}
