package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "STUDENTS")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Student {

    @Id
    @Column(name = "STUDENT_ID", length = 20)
    private String id;                 // e.g. S101

    @Column(name = "NAME", length = 100, nullable = false)
    private String name;

    @Column(name = "ROOM_NO", length = 20)
    private String room;

    @Column(name = "PRESENT")
    private Boolean present;

    @Column(name = "LAST_SCAN", length = 50)
    private String lastScan;

    @Column(name = "DIET", length = 20)
    private String diet;               // Veg / Non-Veg

    @Column(name = "MOBILE", length = 15)
    private String mobile;

    @Column(name = "PARENT_MOBILE", length = 15)
    private String parentMobile;

    @Column(name = "EMAIL", length = 100)
    private String email;

    // --- embedded mess token fields (flattened) ---
    @Column(name = "MESS_TOKEN_DATE", length = 20)
    private String messTokenDate;

    @Column(name = "MESS_TOKEN_CONSUMED")
    private Boolean messTokenConsumed;
}
