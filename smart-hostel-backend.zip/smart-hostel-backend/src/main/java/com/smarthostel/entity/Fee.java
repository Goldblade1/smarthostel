package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity
@Table(name = "FEES")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Fee {

    @Id
    @Column(name = "FEE_ID", length = 20)
    private String id;                 // e.g. F1

    @Column(name = "TYPE", length = 50)
    private String type;               // Hostel Fee / Mess Fee

    @Column(name = "AMOUNT", precision = 12, scale = 2)
    private BigDecimal amount;

    @Column(name = "DEADLINE", length = 20)
    private String deadline;           // ISO date string yyyy-MM-dd

    @Column(name = "PAID")
    private Boolean paid;
}
