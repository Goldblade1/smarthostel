package com.smarthostel.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "LAUNDRY")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Laundry {

    @Id
    @Column(name = "LAUNDRY_ID", length = 20)
    private String id;                 // e.g. L1

    @Column(name = "STUDENT_ID", length = 20, nullable = false)
    private String studentId;

    @Column(name = "STATUS", length = 30)
    private String status;             // Washing / Drying / Ready / Collected

    @Column(name = "MACHINE_NO", length = 20)
    private String machineNo;

    @Column(name = "EST_COMPLETION", length = 30)
    private String estCompletion;

    @Column(name = "PROGRESS")
    private Integer progress;          // 0-100
}
