package com.smarthostel.repository;

import com.smarthostel.entity.MessMenu;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MessMenuRepository extends JpaRepository<MessMenu, String> {
}
