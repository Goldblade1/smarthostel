package com.smarthostel.repository;

import com.smarthostel.entity.ParentMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ParentMessageRepository extends JpaRepository<ParentMessage, String> {
    List<ParentMessage> findByStudentId(String studentId);
}
