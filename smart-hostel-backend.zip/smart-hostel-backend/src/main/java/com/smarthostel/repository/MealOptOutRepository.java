package com.smarthostel.repository;

import com.smarthostel.entity.MealOptOut;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MealOptOutRepository extends JpaRepository<MealOptOut, String> {
    List<MealOptOut> findByStudentId(String studentId);
}
