package com.smarthostel.repository;

import com.smarthostel.entity.WardenProfile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WardenProfileRepository extends JpaRepository<WardenProfile, String> {
}
