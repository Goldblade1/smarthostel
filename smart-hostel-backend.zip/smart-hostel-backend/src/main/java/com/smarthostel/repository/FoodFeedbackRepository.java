package com.smarthostel.repository;

import com.smarthostel.entity.FoodFeedback;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FoodFeedbackRepository extends JpaRepository<FoodFeedback, String> {
    List<FoodFeedback> findByStudentId(String studentId);
}
