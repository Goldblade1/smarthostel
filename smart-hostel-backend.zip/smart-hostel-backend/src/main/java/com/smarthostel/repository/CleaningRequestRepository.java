package com.smarthostel.repository;

import com.smarthostel.entity.CleaningRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CleaningRequestRepository extends JpaRepository<CleaningRequest, String> {
    List<CleaningRequest> findByStudentId(String studentId);
}
