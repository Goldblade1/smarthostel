package com.smarthostel.repository;

import com.smarthostel.entity.Fee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeeRepository extends JpaRepository<Fee, String> {
}
