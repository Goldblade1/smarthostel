package com.smarthostel.repository;

import com.smarthostel.entity.SickFoodRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface SickFoodRequestRepository extends JpaRepository<SickFoodRequest, String> {
    List<SickFoodRequest> findByStudentId(String studentId);
}
