package com.smarthostel.repository;

import com.smarthostel.entity.Laundry;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LaundryRepository extends JpaRepository<Laundry, String> {
    List<Laundry> findByStudentId(String studentId);
}
