package com.smarthostel.repository;

import com.smarthostel.entity.GatePass;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface GatePassRepository extends JpaRepository<GatePass, String> {
    List<GatePass> findByStudentId(String studentId);
    List<GatePass> findByStatus(String status);
}
