package com.smarthostel.service;

import com.smarthostel.entity.GatePass;
import com.smarthostel.repository.GatePassRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class GatePassService {

    private final GatePassRepository gatePassRepository;
    private final StudentService studentService;
    private final AlertService alertService;

    public List<GatePass> getAll() {
        return gatePassRepository.findAll();
    }

    public List<GatePass> getByStudent(String studentId) {
        return gatePassRepository.findByStudentId(studentId);
    }

    // Equivalent of frontend applyGatePass()
    public GatePass apply(GatePass pass) {
        long count = gatePassRepository.count();
        pass.setId("GP" + (count + 1));
        pass.setStatus("Pending");
        pass.setReturned(false);
        return gatePassRepository.save(pass);
    }

    // Equivalent of frontend approveGatePass()
    public GatePass approve(String id, boolean approved) {
        GatePass pass = gatePassRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Gate pass not found: " + id));
        pass.setStatus(approved ? "Approved" : "Rejected");
        gatePassRepository.save(pass);
        if (approved) {
            studentService.toggleAttendance(pass.getStudentId());
        }
        return pass;
    }

    // Equivalent of frontend markReturn()
    public GatePass markReturned(String id) {
        GatePass pass = gatePassRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Gate pass not found: " + id));
        pass.setReturned(true);
        gatePassRepository.save(pass);
        studentService.toggleAttendance(pass.getStudentId());
        return pass;
    }

    // Equivalent of frontend checkOverduePasses() - run periodically or on-demand
    public void checkOverduePasses() {
        LocalDateTime now = LocalDateTime.now();
        for (GatePass pass : gatePassRepository.findByStatus("Approved")) {
            if (Boolean.FALSE.equals(pass.getReturned()) && pass.getExpectedReturn() != null) {
                try {
                    LocalDateTime expected = LocalDateTime.parse(pass.getExpectedReturn());
                    if (now.isAfter(expected)) {
                        alertService.trigger("Overdue Return", pass.getStudentId(),
                                "Student has not returned by deadline.");
                    }
                } catch (DateTimeParseException ignored) {
                    // expectedReturn not in ISO-8601 format; skip check
                }
            }
        }
    }
}
