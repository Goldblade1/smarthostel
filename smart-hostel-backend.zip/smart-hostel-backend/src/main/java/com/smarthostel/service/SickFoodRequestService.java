package com.smarthostel.service;

import com.smarthostel.entity.SickFoodRequest;
import com.smarthostel.repository.SickFoodRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SickFoodRequestService {

    private final SickFoodRequestRepository repository;

    public List<SickFoodRequest> getAll() { return repository.findAll(); }

    public List<SickFoodRequest> getByStudent(String studentId) {
        return repository.findByStudentId(studentId);
    }

    // Equivalent of frontend requestSickFood()
    public SickFoodRequest request(SickFoodRequest req) {
        long count = repository.count();
        req.setId("SF" + (count + 1));
        req.setStatus("Pending");
        return repository.save(req);
    }

    public SickFoodRequest updateStatus(String id, String status) {
        SickFoodRequest req = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sick food request not found: " + id));
        req.setStatus(status);
        return repository.save(req);
    }
}
