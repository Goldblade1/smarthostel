package com.smarthostel.service;

import com.smarthostel.entity.MealOptOut;
import com.smarthostel.repository.MealOptOutRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MealOptOutService {

    private final MealOptOutRepository repository;

    public List<MealOptOut> getAll() { return repository.findAll(); }

    public List<MealOptOut> getByStudent(String studentId) {
        return repository.findByStudentId(studentId);
    }

    // Equivalent of frontend submitOptOut()
    public MealOptOut submit(MealOptOut optOut) {
        long count = repository.count();
        optOut.setId("MO" + (count + 1));
        return repository.save(optOut);
    }
}
