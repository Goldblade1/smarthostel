package com.smarthostel.service;

import com.smarthostel.entity.WardenProfile;
import com.smarthostel.repository.WardenProfileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class WardenProfileService {

    private static final String SINGLETON_ID = "W1";
    private final WardenProfileRepository repository;

    public WardenProfile get() {
        return repository.findById(SINGLETON_ID).orElseGet(() -> {
            WardenProfile wp = WardenProfile.builder()
                    .id(SINGLETON_ID)
                    .name("Super Admin Warden")
                    .zone("Blocks A, B & C")
                    .build();
            return repository.save(wp);
        });
    }

    public WardenProfile update(WardenProfile updated) {
        WardenProfile existing = get();
        existing.setName(updated.getName());
        existing.setZone(updated.getZone());
        return repository.save(existing);
    }
}
