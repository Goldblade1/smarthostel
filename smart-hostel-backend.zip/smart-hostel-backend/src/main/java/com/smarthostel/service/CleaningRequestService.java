package com.smarthostel.service;

import com.smarthostel.entity.CleaningRequest;
import com.smarthostel.repository.CleaningRequestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CleaningRequestService {

    private final CleaningRequestRepository repository;

    public List<CleaningRequest> getAll() { return repository.findAll(); }

    public List<CleaningRequest> getByStudent(String studentId) {
        return repository.findByStudentId(studentId);
    }

    // Equivalent of frontend submitCleaningRequest()
    public CleaningRequest submit(CleaningRequest req) {
        long count = repository.count();
        req.setId("CR" + (count + 1));
        req.setStatus("Pending");
        return repository.save(req);
    }

    // Equivalent of frontend updateCleaningStatus()
    public CleaningRequest updateStatus(String id, String status) {
        CleaningRequest req = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Cleaning request not found: " + id));
        req.setStatus(status);
        return repository.save(req);
    }
}
