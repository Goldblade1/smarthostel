package com.smarthostel.service;

import com.smarthostel.entity.FoodFeedback;
import com.smarthostel.repository.FoodFeedbackRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FoodFeedbackService {

    private final FoodFeedbackRepository repository;

    public List<FoodFeedback> getAll() { return repository.findAll(); }

    public List<FoodFeedback> getByStudent(String studentId) {
        return repository.findByStudentId(studentId);
    }

    // Equivalent of frontend submitFeedback()
    public FoodFeedback submit(FoodFeedback feedback) {
        long count = repository.count();
        feedback.setId("FF" + (count + 1));
        return repository.save(feedback);
    }
}
