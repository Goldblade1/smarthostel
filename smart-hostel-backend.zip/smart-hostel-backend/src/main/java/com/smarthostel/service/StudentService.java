package com.smarthostel.service;

import com.smarthostel.entity.Student;
import com.smarthostel.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;

    public List<Student> getAll() {
        return studentRepository.findAll();
    }

    public Optional<Student> getById(String id) {
        return studentRepository.findById(id);
    }

    public Student create(Student student) {
        if (student.getPresent() == null) student.setPresent(true);
        if (student.getMessTokenConsumed() == null) student.setMessTokenConsumed(false);
        return studentRepository.save(student);
    }

    public Student update(String id, Student updated) {
        Student existing = studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found: " + id));
        existing.setName(updated.getName());
        existing.setMobile(updated.getMobile());
        existing.setEmail(updated.getEmail());
        existing.setParentMobile(updated.getParentMobile());
        existing.setRoom(updated.getRoom());
        existing.setDiet(updated.getDiet());
        return studentRepository.save(existing);
    }

    // Equivalent of frontend markAttendance() - toggles presence
    public Student toggleAttendance(String id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found: " + id));
        student.setPresent(!Boolean.TRUE.equals(student.getPresent()));
        student.setLastScan(LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm a")));
        return studentRepository.save(student);
    }

    // Equivalent of frontend submitDailyAttendance() bulk upload
    public Student setAttendance(String id, boolean present, String date) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found: " + id));
        student.setPresent(present);
        student.setLastScan("Bulk Upload: " + date);
        return studentRepository.save(student);
    }

    // Equivalent of frontend scanMessToken()
    public Student consumeMessToken(String id) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found: " + id));
        student.setMessTokenConsumed(true);
        return studentRepository.save(student);
    }

    public void delete(String id) {
        studentRepository.deleteById(id);
    }
}
