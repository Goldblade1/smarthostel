package com.smarthostel.service;

import com.smarthostel.entity.Alert;
import com.smarthostel.repository.AlertRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AlertService {

    private final AlertRepository alertRepository;

    public List<Alert> getAll() {
        return alertRepository.findAll();
    }

    // Equivalent of frontend triggerAlert() - de-duplicates identical alerts
    public Alert trigger(String type, String studentId, String message) {
        List<Alert> existing = alertRepository.findByStudentIdAndTypeAndMessage(studentId, type, message);
        if (!existing.isEmpty()) {
            return existing.get(0);
        }
        Alert alert = Alert.builder()
                .type(type)
                .studentId(studentId)
                .message(message)
                .time(LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a")))
                .build();
        return alertRepository.save(alert);
    }

    // Equivalent of frontend triggerSOS()
    public Alert triggerSos(String studentId, String room) {
        String msg = "EMERGENCY SOS Triggered from Room " + room +
                ". Alerts sent to Campus Security & Health Center.";
        return trigger("EMERGENCY SOS", studentId, msg);
    }
}
