package com.smarthostel.service;

import com.smarthostel.entity.ParentMessage;
import com.smarthostel.repository.ParentMessageRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ParentMessageService {

    private final ParentMessageRepository repository;

    public List<ParentMessage> getAll() { return repository.findAll(); }

    public List<ParentMessage> getByStudent(String studentId) {
        return repository.findByStudentId(studentId);
    }

    // Equivalent of frontend sendWardenMessage()
    public ParentMessage send(ParentMessage msg) {
        long count = repository.count();
        msg.setId("PM" + (count + 1));
        msg.setStatus("Unread");
        return repository.save(msg);
    }

    // Equivalent of frontend markMessageRead()
    public ParentMessage markRead(String id) {
        ParentMessage msg = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Message not found: " + id));
        msg.setStatus("Read");
        return repository.save(msg);
    }
}
