package com.smarthostel.service;

import com.smarthostel.entity.MessMenu;
import com.smarthostel.repository.MessMenuRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MessMenuService {

    private static final String SINGLETON_ID = "CURRENT";
    private final MessMenuRepository repository;

    public MessMenu get() {
        return repository.findById(SINGLETON_ID).orElseGet(() -> {
            MessMenu menu = MessMenu.builder()
                    .id(SINGLETON_ID)
                    .breakfast("Idli, Sambar, Chutney, Tea/Coffee")
                    .lunch("Rice, Dal, Mixed Veg Curry, Curd")
                    .dinner("Chapati, Paneer Butter Masala/Chicken Curry, Sweet")
                    .build();
            return repository.save(menu);
        });
    }

    public MessMenu update(MessMenu updated) {
        MessMenu existing = get();
        existing.setBreakfast(updated.getBreakfast());
        existing.setLunch(updated.getLunch());
        existing.setDinner(updated.getDinner());
        return repository.save(existing);
    }
}
