package com.smarthostel.service;

import com.smarthostel.entity.Laundry;
import com.smarthostel.repository.LaundryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class LaundryService {

    private final LaundryRepository repository;

    public List<Laundry> getAll() { return repository.findAll(); }

    public List<Laundry> getByStudent(String studentId) {
        return repository.findByStudentId(studentId);
    }

    public Laundry create(Laundry laundry) {
        long count = repository.count();
        laundry.setId("L" + (count + 1));
        return repository.save(laundry);
    }

    public Laundry updateStatus(String id, String status, Integer progress) {
        Laundry laundry = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Laundry record not found: " + id));
        laundry.setStatus(status);
        if (progress != null) laundry.setProgress(progress);
        return repository.save(laundry);
    }
}
