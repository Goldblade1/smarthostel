package com.smarthostel.service;

import com.smarthostel.entity.Complaint;
import com.smarthostel.repository.ComplaintRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplaintService {

    private final ComplaintRepository complaintRepository;

    public List<Complaint> getAll() {
        return complaintRepository.findAll();
    }

    public List<Complaint> getByStudent(String studentId) {
        return complaintRepository.findByStudentId(studentId);
    }

    // Equivalent of frontend submitComplaint()
    public Complaint submit(Complaint complaint) {
        long count = complaintRepository.count();
        complaint.setId("C" + (count + 1));
        complaint.setStatus("Pending");
        return complaintRepository.save(complaint);
    }

    // Equivalent of frontend updateComplaint()
    public Complaint updateStatus(String id, String newStatus) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Complaint not found: " + id));
        complaint.setStatus(newStatus);
        return complaintRepository.save(complaint);
    }
}
