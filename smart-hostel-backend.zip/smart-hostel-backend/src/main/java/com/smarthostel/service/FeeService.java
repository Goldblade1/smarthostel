package com.smarthostel.service;

import com.smarthostel.entity.Fee;
import com.smarthostel.repository.FeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FeeService {

    private final FeeRepository feeRepository;
    private final AlertService alertService;

    public List<Fee> getAll() {
        return feeRepository.findAll();
    }

    public Fee create(Fee fee) {
        return feeRepository.save(fee);
    }

    // Equivalent of frontend payFee()
    public Fee pay(String feeId) {
        Fee fee = feeRepository.findById(feeId)
                .orElseThrow(() -> new RuntimeException("Fee not found: " + feeId));
        fee.setPaid(true);
        return feeRepository.save(fee);
    }

    // Equivalent of frontend checkFeeDeadlines()
    public void checkDeadlines(String recipientStudentId) {
        LocalDate today = LocalDate.now();
        for (Fee fee : feeRepository.findAll()) {
            if (!Boolean.TRUE.equals(fee.getPaid()) && fee.getDeadline() != null) {
                LocalDate deadline = LocalDate.parse(fee.getDeadline());
                if (deadline.isBefore(today)) {
                    alertService.trigger("Fee Overdue", recipientStudentId,
                            fee.getType() + " is overdue! Late fees may apply.");
                }
            }
        }
    }
}
